@extends('layouts.appadmin')
@section('content')
	<link href="{{ asset('css/fullcalendar.css') }}" rel="stylesheet" type='text/css' media="all" />

	<!-- start: Content -->
	<div id="content" class="span10">


	<ul class="breadcrumb">
		<li>
			<i class="icon-home"></i>
			<a href="index.html">Home</a>
			<i class="icon-angle-right"></i>
		</li>
		<li>
			<i class="icon-edit"></i>
			<a href="#">Notification</a>
		</li>
	</ul>
	<div class="row-fluid">

	<div class="span7">
		<h1>Tasks</h1>

		<div class="priority high"><span>high priority</span></div>

		<div class="task high">
			<div class="desc">
				<div class="title">Lorem Ipsum</div>
				<div>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</div>
			</div>
			<div class="time">
				<div class="date">Jun 1, 2012</div>
				<div> 1 day</div>
			</div>
		</div>
		<div class="task high">
			<div class="desc">
				<div class="title">Lorem Ipsum</div>
				<div>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</div>
			</div>
			<div class="time">
				<div class="date">Jun 1, 2012</div>
				<div>1 day</div>
			</div>
		</div>
		<div class="task high">
			<div class="desc">
				<div class="title">Lorem Ipsum</div>
				<div>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</div>
			</div>
			<div class="time">
				<div class="date">Jun 1, 2012</div>
				<div> 1 day</div>
			</div>
		</div>
		<div class="task high last">
			<div class="desc">
				<div class="title">Lorem Ipsum</div>
				<div>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</div>
			</div>
			<div class="time">
				<div class="date">Jun 1, 2012</div>
				<div>1 day</div>
			</div>
		</div>

		<div class="priority medium"><span>medium priority</span></div>

		<div class="task medium">
			<div class="desc">
				<div class="title">Lorem Ipsum</div>
				<div>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</div>
			</div>
			<div class="time">
				<div class="date">Jun 1, 2012</div>
				<div> 1 day</div>
			</div>
		</div>
		<div class="task medium last">
			<div class="desc">
				<div class="title">Lorem Ipsum</div>
				<div>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</div>
			</div>
			<div class="time">
				<div class="date">Jun 1, 2012</div>
				<div> 1 day</div>
			</div>
		</div>

		<div class="priority low"><span>low priority</span></div>

		<div class="task low">
			<div class="desc">
				<div class="title">Lorem Ipsum</div>
				<div>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</div>
			</div>
			<div class="time">
				<div class="date">Jun 1, 2012</div>
				<div> 1 day</div>
			</div>
		</div>
		<div class="task low">
			<div class="desc">
				<div class="title">Lorem Ipsum</div>
				<div>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</div>
			</div>
			<div class="time">
				<div class="date">Jun 1, 2012</div>
				<div> 1 day</div>
			</div>
		</div>
		<div class="task low">
			<div class="desc">
				<div class="title">Lorem Ipsum</div>
				<div>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</div>
			</div>
			<div class="time">
				<div class="date">Jun 1, 2012</div>
				<div> 1 day</div>
			</div>
		</div>
		<div class="task low">
			<div class="desc">
				<div class="title">Lorem Ipsum</div>
				<div>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</div>
			</div>
			<div class="time">
				<div class="date">Jun 1, 2012</div>
				<div> 1 day</div>
			</div>
		</div>
		<div class="task low">
			<div class="desc">
				<div class="title">Lorem Ipsum</div>
				<div>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</div>
			</div>
			<div class="time">
				<div class="date">Jun 1, 2012</div>
				<div> 1 day</div>
			</div>
		</div>
		<div class="task low">
			<div class="desc">
				<div class="title">Lorem Ipsum</div>
				<div>Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit</div>
			</div>
			<div class="time">
				<div class="date">Jun 1, 2012</div>
				<div> 1 day</div>
			</div>
		</div>
		<div class="common-modal modal fade" id="common-Modal1" tabindex="-1" role="dialog" aria-hidden="true">
			<div class="modal-content">
				<ul class="list-inline item-details">
					<li><a href="http://themifycloud.com">Admin templates</a></li>
					<li><a href="http://themescloud.org">Bootstrap themes</a></li>
				</ul>
			</div>
		</div>
		<div class="clearfix"></div>

	</div>

	<div class="span5 noMarginLeft">

		<div class="dark">

		<h1>Timeline</h1>

		<div class="timeline">

				<div class="timeslot">

				<div class="task">
						<span>
						<span class="type">appointment</span>
						<span class="details">
							Dennis Ji at Bootstrap Metro Dashboard HQ
						</span>
						<span>
							remaining time
							<span class="remaining">
								3h 38m 15s
							</span>
						</span>
					</span>
					<div class="arrow"></div>
				</div>
				<div class="icon">
					<i class="icon-map-marker"></i>
				</div>
				<div class="time">
					3:43 PM
				</div>

				</div>

			<div class="clearfix"></div>

			<div class="timeslot alt">

				<div class="task">
						<span>
						<span class="type">phone call</span>
						<span class="details">
							Dennis Ji
						</span>
						<span>
							remaining time
							<span class="remaining">
								3h 38m 15s
							</span>
						</span>
					</span>
					<div class="arrow"></div>
				</div>
				<div class="icon">
					<i class="icon-phone"></i>
				</div>
				<div class="time">
					3:43 PM
				</div>

				</div>

			<div class="timeslot">

				<div class="task">
						<span>
						<span class="type">mail</span>
						<span class="details">
							Dennis Ji
						</span>
						<span>
							remaining time
							<span class="remaining">
								3h 38m 15s
							</span>
						</span>
					</span>
					<div class="arrow"></div>
				</div>
				<div class="icon">
					<i class="icon-envelope"></i>
				</div>
				<div class="time">
					3:43 PM
				</div>

				</div>

			<div class="timeslot alt">

				<div class="task">
						<span>
						<span class="type">deadline</span>
						<span class="details">
							Fixed bugs
						</span>
						<span>
							remaining time
							<span class="remaining">
								3h 38m 15s
							</span>
						</span>
					</span>
					<div class="arrow"></div>
				</div>
				<div class="icon">
					<i class="icon-calendar"></i>
				</div>
				<div class="time">
					3:43 PM
				</div>

				</div>

			<div class="timeslot">

				<div class="task">
						<span>
						<span class="type">appointment</span>
						<span class="details">
							Dennis Ji at Bootstrap Metro Dashboard HQ
						</span>
						<span>
							remaining time
							<span class="remaining">
								3h 38m 15s
							</span>
						</span>
					</span>
					<div class="arrow"></div>
				</div>
				<div class="icon">
					<i class="icon-map-marker"></i>
				</div>
				<div class="time">
					3:43 PM
				</div>

				</div>

			<div class="clearfix"></div>

			<div class="timeslot alt">

				<div class="task">
						<span>
						<span class="type">skype call</span>
						<span class="details">
							Dennis Ji
						</span>
						<span>
							remaining time
							<span class="remaining">
								3h 38m 15s
							</span>
						</span>
					</span>
					<div class="arrow"></div>
				</div>
				<div class="icon">
					<i class="icon-phone"></i>
				</div>
				<div class="time">
					3:43 PM
				</div>

				</div>

			<div class="timeslot">

				<div class="task">
						<span>
						<span class="type">mail</span>
						<span class="details">
							Dennis Ji
						</span>
						<span>
							remaining time
							<span class="remaining">
								3h 38m 15s
							</span>
						</span>
					</span>
					<div class="arrow"></div>
				</div>
				<div class="icon">
					<i class="icon-envelope"></i>
				</div>
				<div class="time">
					3:43 PM
				</div>

				</div>

			<div class="timeslot alt">

				<div class="task">
						<span>
						<span class="type">project deadline</span>
						<span class="details">
							Fixed bugs
						</span>
						<span>
							remaining time
							<span class="remaining">
								3h 38m 15s
							</span>
						</span>
					</span>
					<div class="arrow"></div>
				</div>
				<div class="icon">
					<i class="icon-calendar"></i>
				</div>
				<div class="time">
					3:43 PM
				</div>

				</div>

			<div class="timeslot">

				<div class="task">
						<span>
						<span class="type">mail</span>
						<span class="details">
							Dennis Ji
						</span>
						<span>
							remaining time
							<span class="remaining">
								3h 38m 15s
							</span>
						</span>
					</span>
					<div class="arrow"></div>
				</div>
				<div class="icon">
					<i class="icon-envelope"></i>
				</div>
				<div class="time">
					3:43 PM
				</div>

				</div>

		</div>
	</div>

	</div>

</div>

	<div class="row-fluid sortable">
		<div class="box span12">
			<div class="box-header" data-original-title>
				<h2><i class="halflings-icon white edit"></i><span class="break"></span>Form Elements</h2>
				<div class="box-icon">
					<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
					<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
				</div>
			</div>
			<div class="box-content">
				<form class="form-horizontal">
					<fieldset>
					<div class="control-group">
						<label class="control-label" for="typeahead">Auto complete </label>
						<div class="controls">
						<input type="text" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4" data-source='["Alabama","Alaska","Arizona","Arkansas","California","Colorado","Connecticut","Delaware","Florida","Georgia","Hawaii","Idaho","Illinois","Indiana","Iowa","Kansas","Kentucky","Louisiana","Maine","Maryland","Massachusetts","Michigan","Minnesota","Mississippi","Missouri","Montana","Nebraska","Nevada","New Hampshire","New Jersey","New Mexico","New York","North Dakota","North Carolina","Ohio","Oklahoma","Oregon","Pennsylvania","Rhode Island","South Carolina","South Dakota","Tennessee","Texas","Utah","Vermont","Virginia","Washington","West Virginia","Wisconsin","Wyoming"]'>
						<p class="help-block">Start typing to activate auto complete!</p>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label" for="date01">Date input</label>
						<div class="controls">
						<input type="text" class="input-xlarge datepicker" id="date01" value="02/16/12">
						</div>
					</div>

					<div class="control-group">
						<label class="control-label" for="fileInput">File input</label>
						<div class="controls">
						<input class="input-file uniform_on" id="fileInput" type="file">
						</div>
					</div>
					<div class="control-group hidden-phone">
						<label class="control-label" for="textarea2">Textarea WYSIWYG</label>
						<div class="controls">
						<textarea class="cleditor" id="textarea2" rows="3"></textarea>
						</div>
					</div>
					<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<button type="reset" class="btn">Cancel</button>
					</div>
					</fieldset>
				</form>

			</div>
		</div><!--/span-->

	</div><!--/row-->

	<div class="row-fluid sortable">
		<div class="box span12">
			<div class="box-header" data-original-title>
				<h2><i class="halflings-icon white edit"></i><span class="break"></span>Form Elements</h2>
				<div class="box-icon">
					<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
					<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
				</div>
			</div>
			<div class="box-content">
				<form class="form-horizontal">
					<fieldset>
						<div class="control-group">
						<label class="control-label" for="focusedInput">Focused input</label>
						<div class="controls">
							<input class="input-xlarge focused" id="focusedInput" type="text" value="This is focused…">
						</div>
						</div>
						<div class="control-group">
						<label class="control-label">Uneditable input</label>
						<div class="controls">
							<span class="input-xlarge uneditable-input">Some value here</span>
						</div>
						</div>
						<div class="control-group">
						<label class="control-label" for="disabledInput">Disabled input</label>
						<div class="controls">
							<input class="input-xlarge disabled" id="disabledInput" type="text" placeholder="Disabled input here…" disabled="">
						</div>
						</div>
						<div class="control-group">
						<label class="control-label" for="optionsCheckbox2">Disabled checkbox</label>
						<div class="controls">
							<label class="checkbox">
							<input type="checkbox" id="optionsCheckbox2" value="option1" disabled="">
							This is a disabled checkbox
							</label>
						</div>
						</div>
						<div class="control-group warning">
						<label class="control-label" for="inputWarning">Input with warning</label>
						<div class="controls">
							<input type="text" id="inputWarning">
							<span class="help-inline">Something may have gone wrong</span>
						</div>
						</div>
						<div class="control-group error">
						<label class="control-label" for="inputError">Input with error</label>
						<div class="controls">
							<input type="text" id="inputError">
							<span class="help-inline">Please correct the error</span>
						</div>
						</div>
						<div class="control-group success">
						<label class="control-label" for="inputSuccess">Input with success</label>
						<div class="controls">
							<input type="text" id="inputSuccess">
							<span class="help-inline">Woohoo!</span>
						</div>
						</div>
						<div class="control-group">
						<label class="control-label" for="selectError3">Plain Select</label>
						<div class="controls">
							<select id="selectError3">
							<option>Option 1</option>
							<option>Option 2</option>
							<option>Option 3</option>
							<option>Option 4</option>
							<option>Option 5</option>
							</select>
						</div>
						</div>
						<div class="control-group">
						<label class="control-label" for="selectError">Modern Select</label>
						<div class="controls">
							<select id="selectError" data-rel="chosen">
							<option>Option 1</option>
							<option>Option 2</option>
							<option>Option 3</option>
							<option>Option 4</option>
							<option>Option 5</option>
							</select>
						</div>
						</div>
						<div class="control-group">
						<label class="control-label" for="selectError1">Multiple Select / Tags</label>
						<div class="controls">
							<select id="selectError1" multiple data-rel="chosen">
							<option>Option 1</option>
							<option selected>Option 2</option>
							<option>Option 3</option>
							<option>Option 4</option>
							<option>Option 5</option>
							</select>
						</div>
						</div>
						<div class="control-group">
						<label class="control-label" for="selectError2">Group Select</label>
						<div class="controls">
							<select data-placeholder="Your Favorite Football Team" id="selectError2" data-rel="chosen">
								<option value=""></option>
								<optgroup label="NFC EAST">
									<option>Dallas Cowboys</option>
									<option>New York Giants</option>
									<option>Philadelphia Eagles</option>
									<option>Washington Redskins</option>
								</optgroup>
								<optgroup label="NFC NORTH">
									<option>Chicago Bears</option>
									<option>Detroit Lions</option>
									<option>Green Bay Packers</option>
									<option>Minnesota Vikings</option>
								</optgroup>
								<optgroup label="NFC SOUTH">
									<option>Atlanta Falcons</option>
									<option>Carolina Panthers</option>
									<option>New Orleans Saints</option>
									<option>Tampa Bay Buccaneers</option>
								</optgroup>
								<optgroup label="NFC WEST">
									<option>Arizona Cardinals</option>
									<option>St. Louis Rams</option>
									<option>San Francisco 49ers</option>
									<option>Seattle Seahawks</option>
								</optgroup>
								<optgroup label="AFC EAST">
									<option>Buffalo Dennis Jis</option>
									<option>Miami Dolphins</option>
									<option>New England Patriots</option>
									<option>New York Jets</option>
								</optgroup>
								<optgroup label="AFC NORTH">
									<option>Baltimore Ravens</option>
									<option>Cincinnati Bengals</option>
									<option>Cleveland Browns</option>
									<option>Pittsburgh Steelers</option>
								</optgroup>
								<optgroup label="AFC SOUTH">
									<option>Houston Texans</option>
									<option>Indianapolis Colts</option>
									<option>Jacksonville Jaguars</option>
									<option>Tennessee Titans</option>
								</optgroup>
								<optgroup label="AFC WEST">
									<option>Denver Broncos</option>
									<option>Kansas City Chiefs</option>
									<option>Oakland Raiders</option>
									<option>San Diego Chargers</option>
								</optgroup>
							</select>
						</div>
						</div>
						<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<button class="btn">Cancel</button>
						</div>
					</fieldset>
					</form>

			</div>
		</div><!--/span-->

	</div><!--/row-->

	<div class="row-fluid sortable">
		<div class="box span12">
			<div class="box-header" data-original-title>
				<h2><i class="halflings-icon white edit"></i><span class="break"></span>Form Elements</h2>
				<div class="box-icon">
					<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
					<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
				</div>
			</div>
			<div class="box-content">
				<form class="form-horizontal">
					<fieldset>
						<div class="control-group">
						<label class="control-label" for="prependedInput">Prepended text</label>
						<div class="controls">
							<div class="input-prepend">
							<span class="add-on">@</span><input id="prependedInput" size="16" type="text">
							</div>
							<p class="help-block">Here's some help text</p>
						</div>
						</div>
						<div class="control-group">
						<label class="control-label" for="appendedInput">Appended text</label>
						<div class="controls">
							<div class="input-append">
							<input id="appendedInput" size="16" type="text"><span class="add-on">.00</span>
							</div>
							<span class="help-inline">Here's more help text</span>
						</div>
						</div>
						<div class="control-group">
						<label class="control-label" for="appendedPrependedInput">Append and prepend</label>
						<div class="controls">
							<div class="input-prepend input-append">
							<span class="add-on">$</span><input id="appendedPrependedInput" size="16" type="text"><span class="add-on">.00</span>
							</div>
						</div>
						</div>
						<div class="control-group">
						<label class="control-label" for="appendedInputButton">Append with button</label>
						<div class="controls">
							<div class="input-append">
							<input id="appendedInputButton" size="16" type="text"><button class="btn" type="button">Go!</button>
							</div>
						</div>
						</div>
						<div class="control-group">
						<label class="control-label" for="appendedInputButtons">Two-button append</label>
						<div class="controls">
							<div class="input-append">
							<input id="appendedInputButtons" size="16" type="text"><button class="btn" type="button">Search</button><button class="btn" type="button">Options</button>
							</div>
						</div>
						</div>
						<div class="control-group">
						<label class="control-label">Checkboxes</label>
						<div class="controls">
							<label class="checkbox inline">
							<input type="checkbox" id="inlineCheckbox1" value="option1"> Option 1
							</label>
							<label class="checkbox inline">
							<input type="checkbox" id="inlineCheckbox2" value="option2"> Option 2
							</label>
							<label class="checkbox inline">
							<input type="checkbox" id="inlineCheckbox3" value="option3"> Option 3
							</label>
						</div>
						</div>
						<div class="control-group">
						<label class="control-label">File Upload</label>
						<div class="controls">
							<input type="file">
						</div>
						</div>
						<div class="control-group">
						<label class="control-label">Radio buttons</label>
						<div class="controls">
							<label class="radio">
							<input type="radio" name="optionsRadios" id="optionsRadios1" value="option1" checked="">
							Option one is this and that—be sure to include why it's great
							</label>
							<div style="clear:both"></div>
							<label class="radio">
							<input type="radio" name="optionsRadios" id="optionsRadios2" value="option2">
							Option two can be something else and selecting it will deselect option one
							</label>
						</div>
						</div>
						<div class="form-actions">
						<button type="submit" class="btn btn-primary">Save changes</button>
						<button class="btn">Cancel</button>
						</div>
					</fieldset>
				</form>
			</div>
		</div><!--/span-->

	</div><!--/row-->


</div><!--/.fluid-container-->

	<!-- end: Content -->
	</div><!--/#content.span10-->
		</div><!--/fluid-row-->

	<div class="modal hide fade" id="myModal">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3>Settings</h3>
		</div>
		<div class="modal-body">
			<p>Here settings can be configured...</p>
		</div>
		<div class="modal-footer">
			<a href="#" class="btn" data-dismiss="modal">Close</a>
			<a href="#" class="btn btn-primary">Save changes</a>
		</div>
	</div>

	<div class="clearfix"></div>

	<footer>

		<p>
			<span style="text-align:left;float:left">&copy; 2018 <a href="#">School Admin</a></span>

		</p>

	</footer>

	<!-- start: JavaScript-->

		<script src="{{ asset('js/jquery-1.9.1.min.js') }}"></script>
	<script src="{{ asset('js/jquery-migrate-1.0.0.min.js') }}"></script>

		<script src="{{ asset('js/jquery-ui-1.10.0.custom.min.js') }}"></script>

		<script src="{{ asset('js/jquery.ui.touch-punch.js') }}"></script>

		<script src="{{ asset('js/modernizr.js') }}"></script>

		<script src="{{ asset('js/bootstrap.min.js') }}"></script>

		<script src="{{ asset('js/jquery.cookie.js') }}"></script>

		<script src="{{ asset('js/fullcalendar.min.js') }}"></script>

		<script src="{{ asset('js/jquery.dataTables.min.js') }}"></script>

		<script src="{{ asset('js/excanvas.js') }}"></script>
	<script src="{{ asset('js/jquery.flot.js') }}"></script>
	<script src="{{ asset('js/jquery.flot.pie.js') }}"></script>
	<script src="{{ asset('js/jquery.flot.stack.js') }}"></script>
	<script src="{{ asset('js/jquery.flot.resize.min.js') }}"></script>

		<script src="{{ asset('js/jquery.chosen.min.js') }}"></script>

		<script src="{{ asset('js/jquery.uniform.min.js') }}"></script>

		<script src="{{ asset('js/jquery.cleditor.min.js') }}"></script>

		<script src="{{ asset('js/jquery.noty.js') }}"></script>

		<script src="{{ asset('js/jquery.elfinder.min.js') }}"></script>

		<script src="{{ asset('js/jquery.raty.min.js') }}"></script>

		<script src="{{ asset('js/jquery.iphone.toggle.js') }}"></script>

		<script src="{{ asset('js/jquery.uploadify-3.1.min.js') }}"></script>

		<script src="{{ asset('js/jquery.gritter.min.js') }}"></script>

		<script src="{{ asset('js/jquery.imagesloaded.js') }}"></script>

		<script src="{{ asset('js/jquery.masonry.min.js') }}"></script>

		<script src="{{ asset('js/jquery.knob.modified.js') }}"></script>

		<script src="{{ asset('js/jquery.sparkline.min.js') }}"></script>

		<script src="{{ asset('js/counter.js') }}"></script>

		<script src="{{ asset('js/retina.js') }}"></script>

		<script src="{{ asset('js/custom.js') }}"></script>
	<!-- end: JavaScript-->
@endsection
