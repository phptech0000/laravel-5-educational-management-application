<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/studentregistration', function () {
    return view('auth.studentregistration');
});
Route::post('/Registration_store','UserController@store');
Route::get('/studentregistration2', function () {
    return view('auth.studentregistration2');
});
Route::post('/Registration_store2','UserParentsController@store');
Route::get('/studentregistration3', function () {
    return view('auth.studentregistration3');
});
Route::post('/Registration_store3','UserController@store2');

Route::get('/studentregistration4','UserController@notificationmail');

Route::post('/Registration_store4','UserController@store3');
Route::get('/studentregistrationStatus', function () {
    return view('auth.studentregistraionStatus',['query'=>'']);
});
Route::post('/Registration_store_5','UserController@check');
Route::post('/home/admin','admincontroller@admin');

Route::get('/home/admin', function () {
    return view('Admin');
});
Route::post('/home/admin/delete','admincontroller@delete');
Route::get('/home/admin_registration', function () {
    return view('auth.admin_registration');
});
Route::post('/home/admin_registration','admincontroller@admin_registration');

Route::post('/home/teacher','admincontroller@teacher');
Route::get('/home/teacher_registration', function () {
    return view('auth.teacher_registration');
});
Route::post('/home/teacher/delete','admincontroller@teacher_delete');
Route::post('/home/teacher_registration','admincontroller@teacher_registration');
Route::get('/home/calender', function () {
    return view('calender');
});
Route::get('/home/message', function () {
    return view('message');
});
Route::get('/home/notifications', function () {
    return view('notifications');
});
Route::get('/home/fees', function () {
    return view('fees');
});
Route::get('/home/download', function () {
    return view('download');
});
Route::get('/home/report', function () {
    return view('report');
});
Route::get('/home/chart', function () {
    return view('chart');
});
Route::get('/home/activity-feed', function () {
    return view('activity-feed');
});
Route::get('/home/typography', function () {
    return view('typography');
});
Route::post('/home/gallery','admincontroller@admingallery');
Route::get('/home/icon', function () {
    return view('icon');
});


Route::post('/home/student','admincontroller@student');
Route::get('/home/student', function () {
    return view('Adminstudent');
});
Route::post('/home/student/userdelete','admincontroller@userdelete');
Route::post('/home/student/delete','admincontroller@studentuserdelete');
Route::post('/home/student/Pending/delete','admincontroller@studentdelete');
Route::get('/home/student/Pending','admincontroller@studentpending');
Route::post('/home/admin/studentdocument','admincontroller@studentdoc');
Route::post('/home/admin/studentdocument1','admincontroller@studentdoc1');
Route::post('/home/admin/accept','admincontroller@accept');

Route::get('/home/parents', function () {
    return view('Adminparents');
});
Route::post('/home/parents','admincontroller@parents');
Route::post('/home/parents/parentsdelete','admincontroller@parentsuserdelete');
Route::post('/home/parents/delete','admincontroller@parentsuserdelete');
Route::get('/home/parents/Pending','admincontroller@parentspending');
Route::post('/home/parents/Pending/delete','admincontroller@parentsdelete');
Route::post('/home/parents/accept','admincontroller@parentsaccept');




Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
