<link href="<?php echo e(asset('css/register.css')); ?>" rel="stylesheet">
<?php $__env->startSection('content'); ?><br><br><br><br>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="border:1px solid green;  text-align:center;">
                <div class="card-header">
                  <h2>Student Admission</h2>
            	       <p>Enter your application ID to check status</p>
</div>

                <div class="card-body">
                  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            			<div class="alert alert-danger " style="text-align:center;">
            			 <a href="#" class="close" data-dismiss="alert">&times;</a>
            			 <strong>Error!</strong>		<?php echo e($error); ?>

            			</div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <form enctype="multipart/form-data" id="center-upload-form" action="<?php echo e(URL::to('/Registration_store_5')); ?>" method="post">
            				     <?php echo csrf_field(); ?>
            		      	 <div style="display:none">
            			        	 <input type="hidden" value="af22b8f3a43fe074cfa5daf43f6250eba767f1bc" name="YII_CSRF_TOKEN" />
            		      	 </div>
                        <div class="form-group">
                              <input placeholder="Application Id" name="student_id" id="ApplicationStatus_registration_id" class="form-control"type="text" />
                        </div>
                        <?php if($query != ""): ?>
                         <?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class='alert alert-info'>
                              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>

                          <strong>Your Email is Sucessfully Registered ! </strong> <?php echo e($user->email); ?>

                          <p>Please Reset your Password As Forget Password </p>
                         </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                      <?php endif; ?>
                        <div class="form-group">
                            <?php if($query != ""): ?>
                              <p>** if email is not showing then try after some time your application is under processing ** </p>

                              <a href ="<?php echo e(asset('studentregistrationStatus')); ?>" class="btn btn-primary" >Back </a>
                            <?php else: ?>
                            <input type="submit" class="btn btn-primary" name="yt0" value="Check Status" />
                          <?php endif; ?>
                        </div>
                      </form>
                    <a href="<?php echo e(asset('studentregistration')); ?>">  <h4><strong> New Registraion & New Admission</strong> ?</h4></a>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>