
<!doctype html>
<html>

<head>
	<title>Student Enrolment - Student Information</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Student Registration Form Responsive, Login form web template,Flat Pricing tables,Flat Drop downs  Sign up Web Templates, Flat Web Templates, Login signup Responsive web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
	/>
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- fonts -->
	<link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
	<!-- /fonts -->
	<!-- css -->
	<link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet" type='text/css' media="all" />
	<link href="<?php echo e(asset('css/registernew.css')); ?>" rel="stylesheet" type='text/css' media="all" />
	<!-- /css -->
</head>

<body>

	<div class="content-agileits">
		<h1 class="title">Student Enrolment - Student Information</h1>

    <div style="background:#ccc; padding:20px;">
<a href="<?php echo e(asset('/')); ?>"  style="color:white; float:left; margin-top: 25px;" class="btn btn-primary">Go To Home</a>
      <div class="pagination ">

        <a class="active" href="<?php echo e(asset('new')); ?>" target="_self" title="Student Enrolment - Student Information">1</a>
        <a  href="#" title="Parent Information">2</a>
        <a href="#" title="Documents Upload">3</a>
        <a href="#" title="Finish">4</a>
      </div>
      <form enctype="multipart/form-data" id="students-_step1-form" action="/index.php?r=onlineadmission/registration/step1" method="post">
       <div style="display:none"><input type="hidden" value="af22b8f3a43fe074cfa5daf43f6250eba767f1bc" name="YII_CSRF_TOKEN" /></div>

     <h4 class="text-success">Personal Details</h4>
     <div class="row mb10">

             <div class="col-sm-4">
                 <label class="control-label required" for="Students_first_name">First Name <span class="required">*</span></label>
                  <input class="form-control" placeholder="First Name" required="required" name="Students[first_name]" id="Students_first_name" type="text" />
             </div>

             <div class="col-sm-4">
                 <label class="control-label" for="Students_middle_name">Middle Name</label>
                <input class="form-control" placeholder="Middle Name" name="Students[middle_name]" id="Students_middle_name" type="text" />
             </div>



             <div class="col-sm-4">
                 <label class="control-label required" required="required" for="Students_last_name">Last Name <span class="required">*</span></label>
                 <input class="form-control" required="required" placeholder="Last Name" name="Students[last_name]" id="Students_last_name" type="text" />
             </div>

             <div class="col-sm-4">
                 <label class="control-label" for="Students_national_student_id">Student ID</label>
                 <input class="form-control" required="required" placeholder="Student ID" name="Students[national_student_id]" id="Students_national_student_id" type="text" />
             </div>

                     <div class="col-sm-4">
                <label class="control-label" id="batch_label" for="Students_batch_id">Batch</label>
               <select class="form-control" id="batch_id" name="Students[batch_id]">
<option value="">Select Batch</option>
<option value="1">Grade 11 - Class_A</option>
<option value="2">Grade 11 - Class_B</option>
<option value="3">Grade 12 - Class_A</option>
<option value="4">Grade 12 - Class_B</option>
<option value="5">Humanities and Arts - Psychology</option>
<option value="6">Humanities and Arts - Creative arts</option>
</select>
             </div>


             <div class="col-sm-4">
                 <label class="control-label required" required="required" for="Students_date_of_birth">Date Of Birth <span class="required">*</span></label>
                       <input class="form-control" placeholder="Date Of Birth" id="Students_date_of_birth" name="Students[date_of_birth]" type="date" />
             </div>

                       <div class="col-sm-4">
                 <label class="control-label" for="Students_birth_place">Birth Place</label>
                     <input class="form-control" placeholder="Birth Place" name="Students[birth_place]" id="Students_birth_place" type="text" />
             </div>


             <div class="col-sm-4">
                 <label class="control-label required" for="Students_nationality_id">Nationality <span class="required">*</span></label>                    <select class="form-control" name="Students[nationality_id]" id="Students_nationality_id">
<option value="">Select Nationality</option>
<option value="1">Afghan</option>
<option value="2">Albanian</option>
<option value="3">Algerian</option>
<option value="4">American</option>
<option value="5">Andorran</option>
<option value="6">Angolan</option>
<option value="7">Antiguans</option>
<option value="8">Argentinean</option>
<option value="9">Armenian</option>
<option value="10">Australian</option>
<option value="11">Austrian</option>
<option value="12">Azerbaijani</option>
<option value="13">Bahamian</option>
<option value="14">Bahraini</option>
<option value="15">Bangladeshi</option>
<option value="16">Barbadian</option>
<option value="17">Barbudans</option>
<option value="18">Batswana</option>
<option value="19">Belarusian</option>
<option value="20">Belgian</option>
<option value="21">Belizean</option>
<option value="22">Beninese</option>
<option value="23">Bhutanese</option>
<option value="24">Bolivian</option>
<option value="25">Bosnian</option>
<option value="26">Brazilian</option>
<option value="27">British</option>
<option value="28">Bruneian</option>
<option value="29">Bulgarian</option>
<option value="30">Burkinabe</option>
<option value="31">Burmese</option>
<option value="32">Burundian</option>
<option value="33">Cambodian</option>
<option value="34">Cameroonian</option>
<option value="35">Canadian</option>
<option value="36">Cape Verdean</option>
<option value="37">Central African</option>
<option value="38">Chadian</option>
<option value="39">Chilean</option>
<option value="40">Chinese</option>
<option value="41">Colombian</option>
<option value="42">Comoran</option>
<option value="43">Congolese</option>
<option value="44">Costa Rican</option>
<option value="45">Croatian</option>
<option value="46">Cuban</option>
<option value="47">Cypriot</option>
<option value="48">Czech</option>
<option value="49">Danish</option>
<option value="50">Djibouti</option>
<option value="51">Dominican</option>
<option value="52">Dutch</option>
<option value="53">East Timorese</option>
<option value="54">Ecuadorean</option>
<option value="55">Egyptian</option>
<option value="56">Emirian</option>
<option value="57">Equatorial Guinean</option>
<option value="58">Eritrean</option>
<option value="59">Estonian</option>
<option value="60">Ethiopian</option>
<option value="61">Fijian</option>
<option value="62">Filipino</option>
<option value="63">Finnish</option>
<option value="64">French</option>
<option value="65">Gabonese</option>
<option value="66">Gambian</option>
<option value="67">Georgian</option>
<option value="68">German</option>
<option value="69">Ghanaian</option>
<option value="70">Greek</option>
<option value="71">Grenadian</option>
<option value="72">Guatemalan</option>
<option value="73">Guinea-Bissauan</option>
<option value="74">Guinean</option>
<option value="75">Guyanese</option>
<option value="76">Haitian</option>
<option value="77">Herzegovinian</option>
<option value="78">Honduran</option>
<option value="79">Hungarian</option>
<option value="80">I-Kiribati</option>
<option value="81">Icelander</option>
<option value="82">Indian</option>
<option value="83">Indonesian</option>
<option value="84">Iranian</option>
<option value="85">Iraqi</option>
<option value="86">Irish</option>
<option value="87">Israeli</option>
<option value="88">Italian</option>
<option value="89">Ivorian</option>
<option value="90">Jamaican</option>
<option value="91">Japanese</option>
<option value="92">Jordanian</option>
<option value="93">Kazakhstani</option>
<option value="94">Kenyan</option>
<option value="95">Kittian and Nevisian</option>
<option value="96">Kuwaiti</option>
<option value="97">Kyrgyz</option>
<option value="98">Laotian</option>
<option value="99">Latvian</option>
<option value="100">Lebanese</option>
<option value="101">Liberian</option>
<option value="102">Libyan</option>
<option value="103">Liechtensteiner</option>
<option value="104">Lithuanian</option>
<option value="105">Luxembourger</option>
<option value="106">Macedonian</option>
<option value="107">Malagasy</option>
<option value="108">Malawian</option>
<option value="109">Malaysian</option>
<option value="110">Maldivan</option>
<option value="111">Malian</option>
<option value="112">Maltese</option>
<option value="113">Marshallese</option>
<option value="114">Mauritanian</option>
<option value="115">Mauritian</option>
<option value="116">Mexican</option>
<option value="117">Micronesian</option>
<option value="118">Moldovan</option>
<option value="119">Monacan</option>
<option value="120">Mongolian</option>
<option value="121">Moroccan</option>
<option value="122">Mosotho</option>
<option value="123">Motswana</option>
<option value="124">Mozambican</option>
<option value="125">Namibian</option>
<option value="126">Nauruan</option>
<option value="127">Nepalese</option>
<option value="128">New Zealander</option>
<option value="129">Nicaraguan</option>
<option value="130">Nigerian</option>
<option value="131">Nigerien</option>
<option value="132">North Korean</option>
<option value="133">Northern Irish</option>
<option value="134">Norwegian</option>
<option value="135">Omani</option>
<option value="136">Pakistani</option>
<option value="137">Palauan</option>
<option value="138">Panamanian</option>
<option value="139">Papua New Guinean</option>
<option value="140">Paraguayan</option>
<option value="141">Peruvian</option>
<option value="142">Polish</option>
<option value="143">Portuguese</option>
<option value="144">Qatari</option>
<option value="145">Romanian</option>
<option value="146">Russian</option>
<option value="147">Rwandan</option>
<option value="148">Saint Lucian</option>
<option value="149">Salvadoran</option>
<option value="150">Samoan</option>
<option value="151">San Marinese</option>
<option value="152">Sao Tomean</option>
<option value="153">Saudi</option>
<option value="154">Scottish</option>
<option value="155">Senegalese</option>
<option value="156">Serbian</option>
<option value="157">Seychellois</option>
<option value="158">Sierra Leonean</option>
<option value="159">Singaporean</option>
<option value="160">Slovakian</option>
<option value="161">Slovenian</option>
<option value="162">Solomon Islander</option>
<option value="163">Somali</option>
<option value="164">South African</option>
<option value="165">South Korean</option>
<option value="166">Spanish</option>
<option value="167">Sri Lankan</option>
<option value="168">Sudanese</option>
<option value="169">Surinamer</option>
<option value="170">Swazi</option>
<option value="171">Swedish</option>
<option value="172">Swiss</option>
<option value="173">Syrian</option>
<option value="174">Taiwanese</option>
<option value="175">Tajik</option>
<option value="176">Tanzanian</option>
<option value="177">Thai</option>
<option value="178">Togolese</option>
<option value="179">Tongan</option>
<option value="180">Trinidadian or Tobagonian</option>
<option value="181">Tunisian</option>
<option value="182">Turkish</option>
<option value="183">Tuvaluan</option>
<option value="184">Ugandan</option>
<option value="185">Ukrainian</option>
<option value="186">Uruguayan</option>
<option value="187">Uzbekistani</option>
<option value="188">Venezuelan</option>
<option value="189">Vietnamese</option>
<option value="190">Welsh</option>
<option value="191">Yemenite</option>
<option value="192">Zambian</option>
<option value="193">Zimbabwean</option>
</select>
             </div>


             <div class="col-sm-4">
                 <label class="control-label" for="Students_language">Language</label>                    <input class="form-control" placeholder="Language" name="Students[language]" id="Students_language" type="text" />
             </div>


                       <div class="col-sm-4">
                 <label class="control-label" for="Students_religion">Religion</label>                    <input class="form-control" placeholder="Religion" name="Students[religion]" id="Students_religion" type="text" />
             </div>



             <div class="col-sm-4">
                 <label class="control-label" for="Students_blood_group">Blood </label><br />
                 <select class="form-control" name="Students[blood_group]" id="Students_blood_group">
<option value="">Unknown</option>
<option value="A+">A+</option>
<option value="A-">A-</option>
<option value="B+">B+</option>
<option value="B-">B-</option>
<option value="O+">O+</option>
<option value="O-">O-</option>
<option value="AB+">AB+</option>
<option value="AB-">AB-</option>
</select>
             </div>


             <div class="col-sm-4">
                 <label class="control-label" for="Students_student_category_id">Student Category</label>                    <select class="form-control" name="Students[student_category_id]" id="Students_student_category_id">
<option value="1">General</option>
</select>
             </div>



             <div class="col-sm-4">
                 <label class="control-label required" for="Students_gender">Gender <span class="required">*</span></label><br />
                 <input id="ytStudents_gender" required="required" type="hidden" value="" name="Students[gender]" /><input id="Students_gender_0" value="M" type="radio" name="Students[gender]" /> <label for="Students_gender_0">Male</label> <input id="Students_gender_1" value="F" type="radio" name="Students[gender]" /> <label for="Students_gender_1">Female</label>
             </div>


         <div class="col-sm-4">
<label class="control-label" for="Students_checkbox">checkbox</label>	<br />
<input id="ytStudents_checkbox" type="hidden" value="0" name="Students[checkbox]" /><input value="0" style="float:left;" name="Students[checkbox]" id="Students_checkbox" checked="checked" type="checkbox" />&nbsp; <label style="float:left; margin-left:5px;" for="Students_checkbox"></label>	<div class="clear"></div>
</div><div class="col-sm-4">
<label class="control-label" for="Students_demo">demo</label>	<select class="form-control" name="Students[demo]" id="Students_demo">
<option value="">Select demo</option>
</select>
</div><div class="col-sm-4">
<label class="control-label" for="Students_height">Height</label>	<input placeholder="Height" class="form-control" name="Students[height]" id="Students_height" type="text" value="" />
</div>
<div class="col-sm-4">
<label class="control-label" for="Students_demo1">demo</label>	<input placeholder="demo" class="form-control" name="Students[demo1]" id="Students_demo1" type="text" value="" />
</div>
<div class="col-sm-4">
<label class="control-label" for="Students_demo2">demo1</label>	<input placeholder="demo1" class="form-control" name="Students[demo2]" id="Students_demo2" type="text" value="" />
</div>
<div class="col-sm-4">
<label class="control-label" for="Students_demo3">demo2</label>	<input placeholder="demo2" class="form-control" name="Students[demo3]" id="Students_demo3" type="text" value="" />
</div>
<div class="col-sm-4">
<label class="control-label" for="Students_demo4">demo3</label>	<input placeholder="demo3" class="form-control" name="Students[demo4]" id="Students_demo4" type="text" value="" />
</div>
<div class="col-sm-4">
<label class="control-label" for="Students_demo5">demo4</label>	<input placeholder="demo4" class="form-control" name="Students[demo5]" id="Students_demo5" type="text" value="" />
</div>
<div class="col-sm-4">
<label class="control-label" for="Students_demo6">demo5</label>	<input placeholder="demo5" class="form-control" name="Students[demo6]" id="Students_demo6" type="text" value="" />
</div>
<div class="col-sm-4">
<label class="control-label" for="Students_dem">dem6</label>	<input placeholder="dem6" class="form-control" name="Students[dem]" id="Students_dem" type="text" value="" />
</div>
<div class="col-sm-4">
<label class="control-label" for="Students_dem1">dem6</label>	<input placeholder="dem6" class="form-control" name="Students[dem1]" id="Students_dem1" type="text" value="" />
</div>
<div class="col-sm-4">
<label class="control-label" for="Students_demo7">demo7</label>	<select class="form-control" name="Students[demo7]" id="Students_demo7">
<option value="">Select demo7</option>
</select>
</div>


     </div>
     <br />
     <h4 class="text-success">Contact Details</h4>
     <div class="row mb10">

             <div class="col-sm-4">
                 <label class="control-label required" required="required" for="Students_address_line1">Address Line 1 <span class="required">*</span></label>                    <input class="form-control" placeholder="Address Line 1" name="Students[address_line1]" id="Students_address_line1" type="text" />
             </div>



             <div class="col-sm-4">
                 <label class="control-label required" required="required" for="Students_address_line2">Address Line 2 <span class="required">*</span></label>                    <input class="form-control" placeholder="Address Line 2" name="Students[address_line2]" id="Students_address_line2" type="text" />
             </div>


             <div class="col-sm-4">
                 <label class="control-label required" for="Students_city">City <span class="required">*</span></label>
                 <input class="form-control" required="required" placeholder="City" name="Students[city]" id="Students_city" type="text" />
             </div>



             <div class="col-sm-4">
                 <label class="control-label required" for="Students_state">State <span class="required">*</span></label>
                  <input class="form-control" required="required" placeholder="State" name="Students[state]" id="Students_state" type="text" />
             </div>


             <div class="col-sm-4">
                 <label class="control-label required"  for="Students_pin_code">Pin Code <span class="required">*</span></label>
                                <input class="form-control" required="required" placeholder="Pin Code" name="Students[pin_code]" id="Students_pin_code" type="text" />
             </div>


             <div class="col-sm-4">
                 <label class="control-label required" for="Students_country_id">Country <span class="required">*</span></label>
                                   <select class="form-control" required="required" name="Students[country_id]" id="Students_country_id">
<option value="">Select Country</option>
<option value="1">Afghanistan</option>
<option value="2">Albania</option>
<option value="3">Algeria</option>
<option value="4">Andorra</option>
<option value="5">Angola</option>
<option value="6">Antigua &amp; Deps</option>
<option value="7">Argentina</option>
<option value="8">Armenia</option>
<option value="9">Australia</option>
<option value="10">Austria</option>
<option value="11">Azerbaijan</option>
<option value="12">Bahamas</option>
<option value="13">Bahrain</option>
<option value="14">Bangladesh</option>
<option value="15">Barbados</option>
<option value="16">Belarus</option>
<option value="17">Belgium</option>
<option value="18">Belize</option>
<option value="19">Benin</option>
<option value="20">Bhutan</option>
<option value="21">Bolivia</option>
<option value="22">Bosnia Herzegovina</option>
<option value="23">Botswana</option>
<option value="24">Brazil</option>
<option value="25">Brunei</option>
<option value="26">Bulgaria</option>
<option value="27">Burkina</option>
<option value="28">Burundi</option>
<option value="29">Cambodia</option>
<option value="30">Cameroon</option>
<option value="31">Canada</option>
<option value="32">Cape Verde</option>
<option value="33">Central African Rep</option>
<option value="34">Chad</option>
<option value="35">Chile</option>
<option value="36">China</option>
<option value="37">Colombia</option>
<option value="38">Comoros</option>
<option value="39">Congo</option>
<option value="40">Congo {Democratic Rep}</option>
<option value="41">Costa Rica</option>
<option value="42">Croatia</option>
<option value="43">Cuba</option>
<option value="44">Cyprus</option>
<option value="45">Czech Republic</option>
<option value="46">Denmark</option>
<option value="47">Djibouti</option>
<option value="48">Dominica</option>
<option value="49">Dominican Republic</option>
<option value="50">East Timor</option>
<option value="51">Ecuador</option>
<option value="52">Egypt</option>
<option value="53">El Salvador</option>
<option value="54">Equatorial Guinea</option>
<option value="55">Eritrea</option>
<option value="56">Estonia</option>
<option value="57">Ethiopia</option>
<option value="58">Fiji</option>
<option value="59">Finland</option>
<option value="60">France</option>
<option value="61">Gabon</option>
<option value="62">Gambia</option>
<option value="63">Georgia</option>
<option value="64">Germany</option>
<option value="65">Ghana</option>
<option value="66">Greece</option>
<option value="67">Grenada</option>
<option value="68">Guatemala</option>
<option value="69">Guinea</option>
<option value="70">Guinea-Bissau</option>
<option value="71">Guyana</option>
<option value="72">Haiti</option>
<option value="73">Honduras</option>
<option value="74">Hungary</option>
<option value="75">Iceland</option>
<option value="76">India</option>
<option value="77">Indonesia</option>
<option value="78">Iran</option>
<option value="79">Iraq</option>
<option value="80">Ireland {Republic}</option>
<option value="81">Israel</option>
<option value="82">Italy</option>
<option value="83">Ivory Coast</option>
<option value="84">Jamaica</option>
<option value="85">Japan</option>
<option value="86">Jordan</option>
<option value="87">Kazakhstan</option>
<option value="88">Kenya</option>
<option value="89">Kiribati</option>
<option value="90">Korea North</option>
<option value="91">Korea South</option>
<option value="92">Kosovo</option>
<option value="93">Kuwait</option>
<option value="94">Kyrgyzstan</option>
<option value="95">Laos</option>
<option value="96">Latvia</option>
<option value="97">Lebanon</option>
<option value="98">Lesotho</option>
<option value="99">Liberia</option>
<option value="100">Libya</option>
<option value="101">Liechtenstein</option>
<option value="102">Lithuania</option>
<option value="103">Luxembourg</option>
<option value="104">Macedonia</option>
<option value="105">Madagascar</option>
<option value="106">Malawi</option>
<option value="107">Malaysia</option>
<option value="108">Maldives</option>
<option value="109">Mali</option>
<option value="110">Malta</option>
<option value="111">Montenegro</option>
<option value="112">Marshall Islands</option>
<option value="113">Mauritania</option>
<option value="114">Mauritius</option>
<option value="115">Mexico</option>
<option value="116">Micronesia</option>
<option value="117">Moldova</option>
<option value="118">Monaco</option>
<option value="119">Mongolia</option>
<option value="120">Morocco</option>
<option value="121">Mozambique</option>
<option value="122">Myanmar, {Burma}</option>
<option value="123">Namibia</option>
<option value="124">Nauru</option>
<option value="125">Nepal</option>
<option value="126">Netherlands</option>
<option value="127">New Zealand</option>
<option value="128">Nicaragua</option>
<option value="129">Niger</option>
<option value="130">Nigeria</option>
<option value="131">Norway</option>
<option value="132">Oman</option>
<option value="133">Pakistan</option>
<option value="134">Palau</option>
<option value="135">Panama</option>
<option value="136">Papua New Guinea</option>
<option value="137">Paraguay</option>
<option value="138">Peru</option>
<option value="139">Philippines</option>
<option value="140">Poland</option>
<option value="141">Portugal</option>
<option value="142">Qatar</option>
<option value="143">Romania</option>
<option value="144">Russian Federation</option>
<option value="145">Rwanda</option>
<option value="146">St Kitts &amp; Nevis</option>
<option value="147">St Lucia</option>
<option value="148">Saint Vincent &amp; the Grenadines</option>
<option value="149">Samoa</option>
<option value="150">San Marino</option>
<option value="151">Sao Tome &amp; Principe</option>
<option value="152">Saudi Arabia</option>
<option value="153">Senegal</option>
<option value="154">Serbia</option>
<option value="155">Seychelles</option>
<option value="156">Sierra Leone</option>
<option value="157">Singapore</option>
<option value="158">Slovakia</option>
<option value="159">Slovenia</option>
<option value="160">Solomon Islands</option>
<option value="161">Somalia</option>
<option value="162">South Africa</option>
<option value="163">Spain</option>
<option value="164">Sri Lanka</option>
<option value="165">Sudan</option>
<option value="166">Suriname</option>
<option value="167">Swaziland</option>
<option value="168">Sweden</option>
<option value="169">Switzerland</option>
<option value="170">Syria</option>
<option value="171">Taiwan</option>
<option value="172">Tajikistan</option>
<option value="173">Tanzania</option>
<option value="174">Thailand</option>
<option value="175">Togo</option>
<option value="176">Tonga</option>
<option value="177">Trinidad &amp; Tobago</option>
<option value="178">Tunisia</option>
<option value="179">Turkey</option>
<option value="180">Turkmenistan</option>
<option value="181">Tuvalu</option>
<option value="182">Uganda</option>
<option value="183">Ukraine</option>
<option value="184">United Arab Emirates</option>
<option value="185">United Kingdom</option>
<option value="186">United States</option>
<option value="187">Uruguay</option>
<option value="188">Uzbekistan</option>
<option value="189">Vanuatu</option>
<option value="190">Vatican City</option>
<option value="191">Venezuea</option>
<option value="192">Vietnam</option>
<option value="193">Yemen</option>
<option value="194">Zambia</option>
<option value="195">Zimbabwe</option>
</select>
             </div>



             <div class="col-sm-4">
                 <label class="control-label required" for="Students_phone1">Phone Number <span class="required">*</span></label>
                      <input class="form-control" required="required" placeholder="Phone Number" name="Students[phone1]" id="Students_phone1" type="text" />
             </div>


             <div class="col-sm-4">
                 <label class="control-label" for="Students_phone2">Phone 2</label>
                   <input class="form-control" placeholder="Phone 2" name="Students[phone2]" id="Students_phone2" type="text" />
             </div>


             <div class="col-sm-4">
                 <label class="control-label required" for="Students_email">Email <span class="required">*</span></label>
                        <input class="form-control" required="required" placeholder="Email" name="Students[email]" id="Students_email" type="text" />
             </div>


     </div>
<br>

     <h4 class="text-success">Upload Photo</h4>
      <div class="row mb10">
         <div class="col-sm-12">
         <div class="custm_file">

             <input id="ytStudents_photo_data" type="hidden" value="" name="Students[photo_data]" /><input onChange="readFileName()" name="Students[photo_data]" id="Students_photo_data" type="file" />                    	<span id="display-file-name"></span>
                 </div>

                 <div class="row mb12">
                   <div id="image_size_error" style="color:#F00;"></div>
           <div style="padding-left:10px;" class="upload_file_not">Maximum file size is 1MB. Allowed file types are png,gif,jpeg,jpg</div>
                 </div>
         </div>
     </div>

 <br />
      <div class="row mb10 ">
       <div class="col-md-4">
             <input id="submit_button_form" class="btn btn-success btn-block btn btn-primary btn-lg pull-right" type="submit" name="yt1" value="Save &amp; Continue" />            </div>
     </div>

 </form>
    </div>
		<div class="clear"></div>
	</div>

	<!-- js -->
	<script src="<?php echo e(asset('js/jquery-2.1.4.min.js')); ?>"></script>
	<!-- //js -->

	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/validator.min.js')); ?>"></script>
  <script type="text/javascript">
$('#submit_button_form').click(function(ev) {
	var file_size = $('#Students_photo_data')[0].files[0].size;
	if(file_size>1048576)//File upload size limit to 1mb
	{
		$('#image_size_error').html('File size is greater than 1MB');
		return false;
	}
});


function readFileName() {
	var name	= $('#Students_photo_data')[0].files[0].name;
	$('#display-file-name').html(name);
}
</script>
	<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
<script type="text/javascript">

jQuery(function($) {
jQuery('body').undelegate('#yt0','click').delegate('#yt0','click',function(){return confirm('Are you sure?');});
jQuery('#Students_date_of_birth').datepicker({'showAnim':'fold','dateFormat':'d M yy','changeMonth':true,'changeYear':true,'yearRange':'1900:'});
});

</script>
	<!-- /js files -->
</body>

</html>
