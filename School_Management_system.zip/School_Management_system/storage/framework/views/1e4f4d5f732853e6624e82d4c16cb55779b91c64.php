<?php $__env->startSection('content'); ?>

	<!-- start: Content -->
	<div id="content" class="span10">


	<ul class="breadcrumb">
		<li>
			<i class="icon-home"></i>
			<a href="#">Home</a>
			<i class="icon-angle-right"></i>
		</li>
		<li><a href="#">Messages</a></li>
	</ul>

	<div class="row-fluid">

		<div class="span7">
			<h1>Inbox</h1>

			<ul class="messagesList">
<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a  href="<?php echo e(asset('/home/parents/messageShow')); ?>" onclick="event.preventDefault();
													document.getElementById('message_show<?php echo e($users->id); ?>').submit();">

	<li>
		<span class="from"><span class="icon-envelope"></span><?php if($users->status=='1'): ?><span class="halflings-icon ok"></span><?php endif; ?><i><?php echo e($users->name); ?></i>  </span><span class="title"><?php echo e($users->title); ?></span><span class="date"><?php echo e($users->create_time); ?></span>
	</li>
</a>
	<form id="message_show<?php echo e($users->id); ?>" style="display: none;" enctype="multipart/form-data" action="<?php echo e(url('/home/parents/messageShow')); ?>" method="POST">
								<?php echo csrf_field(); ?>
								<input type="text" value="<?php echo e($users->id); ?>" name="from_id" style="display:none;">

	</form>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</ul>


		</div>
		<div class="span5 noMarginLeft">

			<div class="message dark">
<?php if($queryy != ""): ?>
 <?php $__currentLoopData = $queryy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div  >Title:
				<div class="header">
					<h1><?php echo e($user->title); ?></h1>
					<div class="from"><i class="halflings-icon user"></i> <b><?php echo e($user->name); ?></b> / <?php echo e($user->email); ?></div>
					<div class="date"><i class="halflings-icon time"></i> <?php echo e($user->create_time); ?></div>

					<div class="menu"></div>

				</div>

				<div class="content">
             <?php echo e($user->body); ?>

				</div>

			</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
				<div class="attachments">
					<ul>
          <h1>Send Message</h1>
					</ul>
				</div>
				<div>
				 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				 <div class="alert alert-danger " style="text-align:center;">
	        <a href="#" class="close" data-dismiss="alert">&times;</a>
					<strong>Error!</strong>		<?php echo e($error); ?>

				 </div>

	      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<form class="form-horizontal" enctype="multipart/form-data" action="<?php echo e(url('/home/parents/message/send_message')); ?>" method="POST">
											<?php echo csrf_field(); ?>

					<fieldset>
           <div>
						 <div>To Email:</div>
						<input type="text" required="required" class="span12 typeahead" <?php if($queryy != ""): ?>
						 <?php $__currentLoopData = $queryy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($user->email); ?>"<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						 <?php endif; ?>
						  name="toemail"  / >
          </div>
						<div >
							<div>Title</div>
							<input type="text" required="required" class="span12 typeahead" name="title"  />
						</div>
						<div>
							<div>Body</div>
						<textarea tabindex="3" required="required" class="input-xlarge span12" name="body" id="message" name="body" rows="12" placeholder="Click here to reply"></textarea>
            </div>
						<div class="actions">

							<button tabindex="3" type="submit" class="btn btn-success">Send message</button>

						</div>

					</fieldset>

				</form>

			</div>

		</div>

	</div>



</div><!--/.fluid-container-->

	<!-- end: Content -->
	</div><!--/#content.span10-->
		</div><!--/fluid-row-->

	<div class="modal hide fade" id="myModal">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3>Settings</h3>
		</div>
		<div class="modal-body">
			<p>Here settings can be configured...</p>
		</div>
		<div class="modal-footer">
			<a href="#" class="btn" data-dismiss="modal">Close</a>
			<a href="#" class="btn btn-primary">Save changes</a>
		</div>
	</div>

	<div class="clearfix"></div>

	<footer>

		<p>
			<span style="text-align:left;float:left">&copy; 2018 <a href="#">School Admin</a></span>

		</p>

	</footer>

	<!-- start: JavaScript-->

		<script src="<?php echo e(asset('js/jquery-1.9.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery-migrate-1.0.0.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery-ui-1.10.0.custom.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.ui.touch-punch.js')); ?>"></script>

		<script src="<?php echo e(asset('js/modernizr.js')); ?>"></script>

		<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.cookie.js')); ?>"></script>

		<script src="<?php echo e(asset('js/fullcalendar.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/excanvas.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.flot.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.flot.pie.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.flot.stack.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.flot.resize.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.chosen.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.uniform.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.cleditor.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.noty.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.elfinder.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.raty.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.iphone.toggle.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.uploadify-3.1.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.gritter.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.imagesloaded.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.masonry.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.knob.modified.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.sparkline.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/counter.js')); ?>"></script>

		<script src="<?php echo e(asset('js/retina.js')); ?>"></script>

		<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
	<!-- end: JavaScript-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appparents', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>