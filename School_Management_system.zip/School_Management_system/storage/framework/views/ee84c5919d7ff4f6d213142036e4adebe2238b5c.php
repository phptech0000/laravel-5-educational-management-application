<?php $__env->startSection('content'); ?>
	<link href="<?php echo e(asset('css/fullcalendar.css')); ?>" rel="stylesheet" type='text/css' media="all" />

	<!-- start: Content -->
	<div id="content" class="span10">


	<ul class="breadcrumb">
		<li>
			<i class="icon-home"></i>
			<a href="index.html">Home</a>
			<i class="icon-angle-right"></i>
		</li>
		<li><a href="#">Gallery</a></li>
	</ul>

	<div class="row-fluid sortable">
		<div class="box span12">
			<div class="box-header" data-original-title>
				<h2><i class="halflings-icon white picture"></i><span class="break"></span> Gallery</h2>
				<div class="box-icon">
					<a href="#" id="toggle-fullscreen" class="hidden-phone hidden-tablet"><i class="halflings-icon white fullscreen"></i></a>
					<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
					<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
				</div>
			</div>
			<div class="box-content">
				<div class="masonry-gallery">
					<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div id="image<?php echo e($user->user_id); ?>" class="masonry-thumb">

						<a style="background:url(<?php echo e(asset('storage/'.$user->student_image)); ?>)" title="Roll No. <?php echo e($user->id); ?> & <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>" href="<?php echo e(asset('storage/'.$user->student_image)); ?>"><img class="grayscale" src="<?php echo e(asset('storage/'.$user->student_image)); ?>" alt="Sample Image 1"></a>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>
			</div>
			<div class="common-modal modal fade" id="common-Modal1" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-content">
					<ul class="list-inline item-details">
						<li><a href="http://themifycloud.com">Admin templates</a></li>
						<li><a href="http://themescloud.org">Bootstrap themes</a></li>
					</ul>
				</div>
			</div>
		</div><!--/span-->

	</div><!--/row-->


</div><!--/.fluid-container-->

	<!-- end: Content -->
	</div><!--/#content.span10-->
		</div><!--/fluid-row-->

	<div class="modal hide fade" id="myModal">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3>Settings</h3>
		</div>
		<div class="modal-body">
			<p>Here settings can be configured...</p>
		</div>
		<div class="modal-footer">
			<a href="#" class="btn" data-dismiss="modal">Close</a>
			<a href="#" class="btn btn-primary">Save changes</a>
		</div>
	</div>

	<div class="clearfix"></div>

	<footer>

		<p>
			<span style="text-align:left;float:left">&copy; 2018 <a href="#">School Admin</a></span>

		</p>

	</footer>

	<!-- start: JavaScript-->

		<script src="<?php echo e(asset('js/jquery-1.9.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery-migrate-1.0.0.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery-ui-1.10.0.custom.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.ui.touch-punch.js')); ?>"></script>

		<script src="<?php echo e(asset('js/modernizr.js')); ?>"></script>

		<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.cookie.js')); ?>"></script>

		<script src="<?php echo e(asset('js/fullcalendar.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/excanvas.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.flot.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.flot.pie.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.flot.stack.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.flot.resize.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.chosen.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.uniform.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.cleditor.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.noty.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.elfinder.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.raty.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.iphone.toggle.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.uploadify-3.1.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.gritter.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.imagesloaded.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.masonry.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.knob.modified.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.sparkline.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/counter.js')); ?>"></script>

		<script src="<?php echo e(asset('js/retina.js')); ?>"></script>

		<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
	<!-- end: JavaScript-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appadmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>