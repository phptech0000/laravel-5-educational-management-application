<?php $__env->startSection('content'); ?>
	<link href="<?php echo e(asset('css/jquery.cleditor.css')); ?>" rel="stylesheet" type='text/css' />

	<!-- start: Content -->
	<div id="content" class="span10">
	<ul class="breadcrumb">
		<li>
			<i class="icon-home"></i>
			<a href="#">Home</a>
			<i class="icon-angle-right"></i>
		</li>
		<li>
			<i class="icon-edit"></i>
			<a href="#">Notification</a>
		</li>
	</ul>
	<div class="row-fluid">

	<div class="span12">
		<h1>Notification</h1>

		<div class="priority high"><span>Recently 15 Notification</span></div>
<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


		<div class="task high">
			<div class="desc">

				<summary class="title"> <?php echo e($notify->headline); ?>

				</summary>
				<?php if($notify->brief !=""): ?>
				<details>
				<div><?php echo $notify->brief ;?></div>
				<?php if($notify->file!=""): ?>
		  	<div >
					<a href="<?php echo e(asset('storage/'.substr($notify->file,7))); ?>" download>
              <i style="margin-left:5px;" class="halflings-icon download"></i>
							File:- <?php echo e($notify->file_name); ?>

					</a>
		  	</div>
			<?php endif; ?>
			</details>
		<?php endif; ?>
			</div>

			<div class="time">
				<div class="date" style="font-size:20px;"><?php echo e($date); ?><span style="font-size:10px;"> Days Before</span></div>
			<div style="font-size:8px;"><?php echo e($notify->create_time); ?></div>
			</div>
		</div>
		<div class="clearfix"></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


	</div>



		</div>
	</div>

	</div>

</div>
<br><br>
	<div class="row-fluid sortable">

	</div><!--/row-->


</div><!--/.fluid-container-->

	<!-- end: Content -->
	</div><!--/#content.span10-->
		</div><!--/fluid-row-->



	<div class="clearfix"></div>

	<footer>

		<p>
			<span style="text-align:left;float:left">&copy; 2018 <a href="#">School Admin</a></span>

		</p>

	</footer>

	<!-- start: JavaScript-->

		<script src="<?php echo e(asset('js/jquery-1.9.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery-migrate-1.0.0.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery-ui-1.10.0.custom.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.ui.touch-punch.js')); ?>"></script>

		<script src="<?php echo e(asset('js/modernizr.js')); ?>"></script>

		<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.cookie.js')); ?>"></script>

		<script src="<?php echo e(asset('js/fullcalendar.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/excanvas.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.flot.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.flot.pie.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.flot.stack.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery.flot.resize.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.chosen.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.uniform.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.cleditor.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.noty.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.elfinder.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.raty.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.iphone.toggle.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.uploadify-3.1.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.gritter.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.imagesloaded.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.masonry.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.knob.modified.js')); ?>"></script>

		<script src="<?php echo e(asset('js/jquery.sparkline.min.js')); ?>"></script>

		<script src="<?php echo e(asset('js/counter.js')); ?>"></script>

		<script src="<?php echo e(asset('js/retina.js')); ?>"></script>

		<script src="<?php echo e(asset('js/custom.js')); ?>"></script>
	<!-- end: JavaScript-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appteacher', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>